<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" integrity="sha384-Bfad6CLCknfcloXFOyFnlgtENryhrpZCe29RTifKEixXQZ38WheV+i/6YWSzkz3V" crossorigin="anonymous">
    <link href="sticky-foooter.css" rel="stylesheet">
    <title>Secence</title>
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
  </head>
  <body>
    <!--Nav bar-->

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
  <a class="navbar-brand" href="#">Secence Developments</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
    <li class="nav-item active">
        <a class="nav-link" href="index.php">Home </span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="systems.php">Systems</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Featured Products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Our Team</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
    </ul>
  </div>
</nav>

<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">WELCOME TO SECENCE DEVELOPMENT</h1>
    <p class="lead">Protect your family members</p>
  </div>
</div>

<div class="container text-center">
    <hr>
    <h1 class="h3">Best Real-Time Home Securing & Automation Solutions In Sri Lanka</h1>
    <hr>
</div>
<br>
<br><br>
<br>
<div class="container text-center">
<h1 class="display-4">Why choose us?</h1>
    <br>
<div class="row">
    <div class="col-sm">
    <i class="fas fa-globe fa-4x"></i>
    <br><br>
    <p class="h5 lead">EVERYWHERE YOU WITH YOUR <br> HOME</p>
    </div>
    <div class="col-sm">
    <i class="fas fa-stamp fa-4x"></i>
    <br><br>
    <p class="h5 lead">100% SATISFACTION GUARANTEE</p>
    </div>
    <div class="col-sm">
    <i class="fas fa-wrench fa-4x"></i>
    <br><br>
    <p class="h5 lead">QUALIFIED TECHNIAL TEAMS</p>
    </div>
  </div>

  <br><br><br>

  <div class="container">

    <h1 class="display-4">Featured products</h1>
    <br>
    <p class="h5 lead">There are several new products added to your service from our Innovation section. All products can be customized to suit your needs. Be aware of our new products today.</p>
    <br>
  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/1.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<br><br>
<button type="button" style="border-radius: 0;" class="btn btn-dark btn-lg">
  See the complete offer</button>
  </div>

</div>
<br><br>
<div class="container-fluid bg-dark text-center text-white">
  <br>
  <div class="container">
    <br>
    <h1 class="display-4">Choose the product that suits you</h1>
    <br><br>
    <p class="h5 lead">Our staff is committed to providing you with the service you need whenever you need it. Contact our Consumer Affairs section at any time of the day to get information about the service that best suits your needs. Thank You.</p>
  
  </div>
  <br>
  <button type="button" style="border-radius: 0;" class="btn btn-light btn-lg">Contact our agents</button>
    <br><br><br><br>
</div>
<br><br><br><br>
<footer class="footer mt-auto py-3">
  <div class="container" id="stick">
    <span>© 2020 Secence Developments. Kurunegala, 60500</span> <br>
    <span>Powered by Name</span>
  </div>
</footer>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
  </body>
</html>